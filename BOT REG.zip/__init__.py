from telethon import *
import datetime as DT
from telethon import *
from dotenv import load_dotenv
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import logging
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

api_id = os.getenv('MY_API') 
api_hash = os.getenv('MY_HASH')
bot_token = os.getenv('MY_BOT')

# Inisialisasi bot
bot = TelegramClient('bot_session', api_id, api_hash).start(bot_token=bot_token)

def valid(id):
	url = "https://api3.scrapers.web.id/admin/api/v1/user/telegram/valid/{id}"

	try:
		response = requests.get(url)

		if response.status_code == 200:
			data = response.json()

			if data.get("massage") == "valid":
				return "true"
			else:
				return "false"
		else:
			return "false, error: {response.status_code}"
		
	except Exception as e:
        # Tangani jika terjadi error pada request
		return "false, Error: {e}"