from telethon import *
import datetime as DT
from dotenv import load_dotenv
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import logging
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

#chmod 644 .env
load_dotenv(dotenv_path = "botreg/.env")

api_id = os.getenv('MY_API') 
api_hash = os.getenv('MY_HASH')
bot_token = os.getenv('MY_BOT')

# Inisialisasi bot
bot = TelegramClient('bot_session', api_id, api_hash).start(bot_token=bot_token)

def calculate_date(exp):
    today = DT.now()
    target_date = today + timedelta(days=exp)
    # Format tanggal menjadi `YYYY-MM-DD`
    formatted_date = target_date.strftime("%d-%m-%Y")
    return formatted_date

def valid(id):
    # Susun URL dengan f-string
    url = f"https://api3.scrapers.web.id/admin/api/v1/user/telegram/valid/{id}"
    
    try:
        # Kirim permintaan GET
        response = requests.get(url)

        # Jika status kode adalah 200, cek data JSON
        if response.status_code == 200:
            data = response.json()
            if data.get("massage") == "valid":  # Periksa nilai 'massage' di JSON
                return "true"
            else:
                return "false"
        else:
            # Tangani status kode selain 200
            return f"false, error: {response.status_code}"
    
    except Exception as e:
        # Tangani jika ada error dalam request
        return f"false, Error: {str(e)}"
