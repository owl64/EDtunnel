from botreg import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" 🛒 Register IP ","regip")],
[Button.inline(" 🔄 Renew IP ","renip"),
Button.inline(" 🔒 Change IP ","changip")],
[Button.inline(" 🗑️ Delete IP ","delip")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer(" ❌ **Akses ditolak**", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
**📊 PANEL REG SC **
━━━━━━━━━━━━━━━━━━━━━━━━━━
💌 Chat admin untuk harga yang lebih murah
⏸️ ID: {str(sender.id)}

🤖 Harga List SC:

✅ 1. 1/month Rp. 8000
✅ 2. 3/month Rp. 20000
✅ 3. 6/month Rp. 40000
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


