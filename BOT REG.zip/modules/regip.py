from botreg import *

@bot.on(events.CallbackQuery(data=b'buysc1'))
async def buy_sc1(event):
    sender = await event.get_sender()
    chat = event.chat_id
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer(" ❌ **Akses ditolak**", alert=True)
        except Exception as e:
            await event.reply(f"Akses ditolak, error: {e}")
    elif val == "true":
        try:
            async with bot.conversation(chat) as user:
                tusr=f"""
❗ **Perhatian:**
Gunakan huruf dan angka untuk membuat username.
**Masukkan Username:**
"""
                await event.respond(tusr)
                user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = (await user).raw_text
            async with bot.conversation(chat) as ipadd:
                tipadd=f"""
❗ **Perhatian:**
Silakan masukkan IP address yang valid.
Contoh: `192.168.1.1` atau `10.0.0.1`

** IP Address : **
"""
                await event.respond(tipadd)
                while True:
                    try:
                        ip_input = await ipadd.get_response()

                        ip_pattern = r"^(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\." \
                                    r"(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\." \
                                    r"(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\." \
                                    r"(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$"

                        if re.match(ip_pattern, ip_input.raw_text):
                            ip_address = ip_input.raw_text
                            break
                        else:
                            await ipadd.send_message("❌ **IP address tidak valid.** Silakan coba lagi.")
                    except Exception as e:
                        await ipadd.send_message(f"❌ Terjadi kesalahan: {e}")
                        break

            async with bot.conversation(chat) as exp:
                texp=f"""
Note: __Mohon Berhati-hati,__
__Saat memilih.__
** Expired(Month) : **
    """
                await event.respond(texp,buttons=[
    [Button.inline(" 1 Bulan ","30"), Button.inline(" 3 Bulan ","90")],
    [Button.inline(" 6 Bulan ","180"),]])
                exp = exp.wait_event(events.CallbackQuery)
                exp = (await exp).data.decode("ascii")
            versi = "1.0"
            updat = "1.1"
            price = 8000
            texp = calculate_date(exp)
            month = exp/30

            sumtot = price*month

            inline_button = [
                    [Button.inline(" ✅ Ya ","confir"), Button.inline(" ❌ Tidak ","batal")]
                ]
            msg = f"""
    ━━━━━━━━━━━━━━━━━━━━
    ✅** KONFIRMASI PEMBELIAN? **
    ━━━━━━━━━━━━━━━━━━━━
    💌 Detail Pembelian:

    📄 Sc Version: {versi}
    ⚠️ Expired: {texp}
    💵 Harga: Rp. {sumtot}

    Tekan tombol ya untuk melanjutkan:
    """
                
            await event.edit(msg, buttons=inline_button)
            confirm_event = await bot.wait_event(events.CallbackQuery)

            if confirm_event.data == b"batal":
                await event.edit("❌ Proses dibatalkan.", alert=True)
                return  # Keluar dari seluruh proses
            elif confirm_event.data == b"confir":
                await event.edit("⏳ Pembelian diproses...", alert=True)

            if confirm_event:
                api_url = "http://api3.scrapers.web.id/admin/api/v1/user/buy-sc"
            payload = json.dumps({
                "telegramid": sender.id,
                "user": user,
                "exp": texp,
                "ipaddress": ip_address,
                "version": versi,
                "update": updat,
                "price": price,
                "month": month
            })
            headers = {
                'Content-Type': 'application/json'
            }

            response = requests.post(api_url, headers=headers, data=payload)

            if response.status_code == 200:
                msg_sc = f"""
✅ Pembelian berhasil!.
━━━━━━━━━━━━━━━━━━━━

📚Ikuti Instruksi dibawah:

🛠️ Sc Support :
✅ Debian 10
✅ Ubuntu 20.04, Ubuntu 22.04

Pertama : 
```
screen
```
tekan [ENTER].

Kedua :
🔔 Hanya Copy dan Paste di VPS:
```
apt install -y && apt update -y && apt upgrade -y && apt install lolcat -y && gem install lolcat && wget -q https://repo2.serv00.com/git/pub/hermawandi64/AutoSC/plain/setup_ins.sh && chmod +x setup_ins.sh && ./setup_ins.sh
```

📄 Kemudian Pilih angka 1
━━━━━━━━━━━━━━━━━━━━
Hubungi admin jika bermasalah
📩@andiowl
"""
                await event.edit(msg_sc, alert=True)
            else:
                await event.edit(f"❌ Pembelian gagal! Error: {response.text}", alert=True)

        except Exception as e:
            await event.reply(f"Hubungi admin, error: {e}")

@bot.on(events.CallbackQuery(data=b'sc1'))
async def sc1(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer(" ❌ **Akses ditolak**", alert=True)
        except Exception as e:
            await event.reply(f"Akses ditolak, error: {e}")
    elif val == "true":
        try:
            inline_button = [
                [Button.inline(" ✅ Konfirmasi ","buysc1"), Button.inline(" 🚪 Kembali ","regip")]
            ]
            msg = f"""
━━━━━━━━━━━━━━━━━━━━
  ✅** KONFIRMASI PEMBELIAN? **
━━━━━━━━━━━━━━━━━━━━
💌 Kamu akan melakukan Pembelian sebagai
Berikut:

📄 Sc Version: 1.0
💵 Harga: Akan ditentukan nanti

Tekan tombol dibawah ini:
"""
            x = await event.edit(msg,buttons=inline_button)
            if not x:
                await event.reply(msg,buttons=inline_button)
        
        except Exception as e:
            await event.reply(f"Hubungi admin, error: {e}")

@bot.on(events.CallbackQuery(data=b'regip'))
async def regip(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer(" ❌ **Akses ditolak**", alert=True)
        except Exception as e:
            await event.reply(f"Akses ditolak, error: {e}")
    elif val == "true":
        try:
            inline_button = [
                [Button.inline(" 🚀 SC Versi 1 ","sc1"), Button.inline(" 🚀 SC versi 2","sc2")],
                [Button.inline(" 🚪 Kembali ","menu")]
            ]
            msg = f"""
━━━━━━━━━━━━━━━━━━━━
  📄** REGISTRASI NEW IP **
━━━━━━━━━━━━━━━━━━━━
⏸️ ID: {str(sender.id)}
💵 Saldo: 

💵 Harga :
✅ 1. 1/month Rp. 8000
✅ 2. 3/month Rp. 20000
✅ 3. 6/month Rp. 40000

Hubungi admin, jika bermasalah
📩@andiowl
━━━━━━━━━━━━━━━━━━━━
"""
            x = await event.edit(msg,buttons=inline_button)
            if not x:
                await event.reply(msg,buttons=inline_button)
        
        except Exception as e:
            await event.reply(f"Hubungi admin, error: {e}")