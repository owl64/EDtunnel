from botreg import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.url("Owner","https://t.me/andiowl"),
Button.url("Topup Saldo","https://t.me/andiowl")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
**🏠 SDC NETWORK **
━━━━━━━━━━━━━━━━━━━━━━━━━━ 
🎉 Selamat Datang di Bot RegIP ini 🎉
🤖 Saya di sini untuk membantu kebutuhan Anda

🔍 Ketik:
[/menu] - Untuk Melihat Menu
[/regis] - Untuk Mendaftarkan IDTelegram

🛒 Untuk Melakukan Topup Hubungi admin
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)





