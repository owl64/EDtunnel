from botreg import *

@bot.on(events.NewMessage(pattern=r"(?:.regis|/regis)$"))
@bot.on(events.CallbackQuery(data=b'regis'))
async def regis(event):
	sender = await event.get_sender()
	val = str(sender.id)
	url = "https://api3.scrapers.web.id/admin/api/v1/user/create-tele"
	payloads = ({"telegramid": val})
	headers = {'Content-Type': 'application/json'}
	response = requests.request("POST", url, headers=headers, data=payloads)
	if response.status_code == 201:
		data = response.json()
		if data.get("massage") == "TelegramID Submited successfully":
			msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
**  ✅ Success Mendaftarkan ID **
━━━━━━━━━━━━━━━━━━━━━━━━━━ 
🎉 Selamat Datang di Bot RegIP ini 🎉
🤖 Saya di sini untuk membantu kebutuhan Anda

🔍 Ketik:
[/menu] - Untuk Melihat Menu

🛒 Untuk Melakukan Topup Hubungi admin
            """
			x = await event.edit(msg)
			if not x:
				await event.reply(msg)
		
		elif data.get("error") == "ID already available":
			msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
   ⏩ ID Sudah Terdaftar
━━━━━━━━━━━━━━━━━━━━━━━━━━ 
"""
			x = await event.edit(msg)
			if not x:
				await event.reply(msg)
	else:
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
**  ❌ Gagal Mendaftarkan ID **
━━━━━━━━━━━━━━━━━━━━━━━━━━ 
🤖 Ulangi 3X, jika gagal Hubungi Admin
"""
		x = await event.edit(msg)
		if not x:
			await event.reply(msg)





